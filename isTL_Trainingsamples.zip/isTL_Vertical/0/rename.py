import os
##输入新的文件名
print("开始重新命名图片:")
#newname = newname.strip()
#if newname != '':
    ##获取当前文件夹的路径
path = os.getcwd()
##要修改的文件的格式
pic_ext = ['.jpg','.png']
i = 0
for file in os.listdir(path):
    if os.path.isfile(file) == True:
        name,ext = os.path.splitext(file)
        print(ext)
        if ext in pic_ext:
             i = i+1
             newname1 = str(i) + ext
             os.rename(file,newname1)


print("完成重命名！")